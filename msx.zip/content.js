// ===== MsX Content Script - Rewards Page Task Clicker =====
// This script is injected into rewards.bing.com to find and click task links

(function () {
  'use strict';

  // ===== Get clickable task links in a section =====
  function getTaskLinksInSection(sectionId) {
    let section;
    if (sectionId === 'quest_page') {
      section = document.querySelector('.bg-rewardsTableAltBg') || document.body;
    } else {
      section = document.querySelector(`#${sectionId}`);
    }

    if (!section) {
      console.log(`[MsX] Section ${sectionId} not found on this page`);
      return [];
    }

    const allLinks = section.querySelectorAll('a[href][data-rac]');
    const taskLinks = [];

    allLinks.forEach((link, index) => {
      const href = link.getAttribute('href');

      // Skip navigation-only links
      if (!href || href === '/earn' || href === '/earn/' || href === '/dashboard' || href === '/dashboard/') {
        return;
      }

      const titleEl = link.querySelector('.text-globalBody2Strong, .line-clamp-3, span');
      const title = titleEl ? titleEl.textContent.trim() : `Task ${index + 1}`;
      const completed = isTaskCompleted(link);

      taskLinks.push({
        index: taskLinks.length,
        elementIndex: index,
        href,
        title,
        completed
      });
    });

    console.log(`[MsX] Section ${sectionId}: found ${taskLinks.length} task links`, taskLinks);
    return taskLinks;
  }

  // ===== Click a specific task link by its NodeList index =====
  function clickTaskInSection(sectionId, elementIndex) {
    let section;
    if (sectionId === 'quest_page') {
      section = document.querySelector('.bg-rewardsTableAltBg') || document.body;
    } else {
      section = document.querySelector(`#${sectionId}`);
    }

    if (!section) {
      return { success: false, error: `Section ${sectionId} not found` };
    }

    const allLinks = section.querySelectorAll('a[href][data-rac]');
    if (elementIndex >= allLinks.length) {
      return { success: false, error: `Link index ${elementIndex} out of bounds (total: ${allLinks.length})` };
    }

    const link = allLinks[elementIndex];
    const href = link.getAttribute('href');
    const title = link.querySelector('.text-globalBody2Strong, .line-clamp-3, span')?.textContent?.trim() || 'Unknown';

    // Force open in new tab so we don't lose the current page
    link.setAttribute('target', '_blank');
    link.click();

    console.log(`[MsX] Clicked task: "${title}" → ${href}`);
    return { success: true, href, title };
  }

  // ===== Check if task is already completed =====
  function isTaskCompleted(cardElement) {
    // Check 1: progress text like "6/6 tasks", "5/5 tasks"
    const progressText = cardElement.querySelector('[class*="wrap-anywhere"]');
    if (progressText) {
      const text = progressText.textContent.trim();
      const match = text.match(/(\d+)\/(\d+)/);
      if (match) {
        const current = parseInt(match[1]);
        const total = parseInt(match[2]);
        if (current >= total) return true;
      }
    }

    // Check 2: green checkmark badge (bg-statusSuccessRewardsBg)
    const successBadge = cardElement.querySelector('[class*="statusSuccessRewardsBg"]');
    if (successBadge) return true;

    return false;
  }

  // ===== Click the "Points breakdown" card on /earn page =====
  async function clickPointsBreakdown() {
    const allMetadata = document.querySelectorAll('p.text-metadata');
    let clicked = false;
    for (const el of allMetadata) {
      if (el.textContent.trim().toLowerCase() === 'points breakdown') {
        let card = el.closest('[class*="cursor-pointer"]');
        if (card) {
          card.click();
          console.log('[MsX] Clicked Points breakdown card');
          clicked = true;
          break;
        }
      }
    }
    if (!clicked) {
      console.warn('[MsX] Points breakdown card not found');
      return { success: false, error: 'Points breakdown card not found' };
    }

    // Poll until the breakdown dialog appears (max 5s), similar to extractEmail flyout
    let dialog = null;
    for (let i = 0; i < 10; i++) {
      await new Promise(r => setTimeout(r, 500));
      dialog = document.querySelector('section[role="dialog"]');
      if (dialog) break;
    }
    if (!dialog) {
      return { success: false, error: 'Points breakdown dialog did not appear' };
    }

    console.log('[MsX] Points breakdown dialog appeared');
    return { success: true };
  }

  // ===== Close the currently open dialog (click the X / Close button) =====
  function closeDialog() {
    // The close button lives inside section[role="dialog"] and has aria-label="Close" + slot="close"
    const closeBtn = document.querySelector('section[role="dialog"] button[aria-label="Close"][slot="close"]');
    if (closeBtn) {
      closeBtn.click();
      console.log('[MsX] Dialog closed');
      return { success: true };
    }
    console.warn('[MsX] Close button not found in dialog');
    return { success: false, error: 'Close button not found' };
  }

  // ===== Extract data from Points breakdown dialog =====
  function extractPointsBreakdown() {
    // The dialog is a <section role="dialog"> containing the breakdown
    const dialog = document.querySelector('section[role="dialog"]');
    if (!dialog) {
      return { success: false, error: 'Points breakdown dialog not open' };
    }

    const data = {
      todayPoints: null,
      activity: {
        desktopSearch: { earned: null, max: null },
        mobileSearch: { earned: null, max: null },
        offers: null
      },
      history: {
        thisMonth: null,
        thisYear: null,
        lifetime: null
      }
    };

    // --- Today's points (big header number) ---
    const headerNum = dialog.querySelector('p.text-pageHeader');
    if (headerNum) {
      data.todayPoints = parseInt(headerNum.textContent.trim().replace(/,/g, ''), 10);
    }

    // --- Today's activity table ---
    // Rows: each row has a <p> label + earned/max spans
    const activityRows = dialog.querySelectorAll('.wrap-anywhere p');
    activityRows.forEach(labelEl => {
      const label = labelEl.textContent.trim().toLowerCase();
      // The points cell is the sibling .wrap-anywhere.justify-self-end in the same grid row
      // Walk up to the row container (the <span>-less div in the grid)
      const rowContainer = labelEl.closest('.py-3.wrap-anywhere');
      if (!rowContainer) return;

      // The next sibling grid cell holds the value
      let valueCell = rowContainer.nextElementSibling;
      // Skip empty <span> separators
      while (valueCell && valueCell.tagName === 'SPAN') {
        valueCell = valueCell.nextElementSibling;
      }
      if (!valueCell) return;

      const earnedSpan = valueCell.querySelector('span.font-semibold');
      const maxSpan = valueCell.querySelector('span.text-fgCtrlNeutralSecondaryRest');

      if (label.includes('desktop')) {
        data.activity.desktopSearch.earned = earnedSpan ? parseInt(earnedSpan.textContent.replace(/,/g, ''), 10) : null;
        data.activity.desktopSearch.max = maxSpan ? parseInt(maxSpan.textContent.replace(/[^0-9]/g, ''), 10) : null;
      } else if (label.includes('mobile')) {
        data.activity.mobileSearch.earned = earnedSpan ? parseInt(earnedSpan.textContent.replace(/,/g, ''), 10) : null;
        data.activity.mobileSearch.max = maxSpan ? parseInt(maxSpan.textContent.replace(/[^0-9]/g, ''), 10) : null;
      } else if (label.includes('offers')) {
        // Offers cell has a plain text number (no spans)
        const raw = valueCell.textContent.trim().replace(/,/g, '');
        data.activity.offers = raw ? parseInt(raw, 10) : null;
      }
    });

    // --- History table ---
    // Rows: plain text label + plain text value
    const historyWrappers = dialog.querySelectorAll('.wrap-anywhere:not(.justify-self-end)');
    historyWrappers.forEach(el => {
      const text = el.textContent.trim().toLowerCase();
      // The next grid sibling is the value cell
      let valueCell = el.nextElementSibling;
      while (valueCell && valueCell.tagName === 'SPAN') {
        valueCell = valueCell.nextElementSibling;
      }
      if (!valueCell) return;
      const value = parseInt(valueCell.textContent.trim().replace(/,/g, ''), 10);
      if (isNaN(value)) return;

      if (text === 'this month') data.history.thisMonth = value;
      else if (text === 'this year') data.history.thisYear = value;
      else if (text === 'lifetime') data.history.lifetime = value;
    });

    console.log('[MsX] Points breakdown extracted:', data);
    return { success: true, data };
  }

  // ===== Extract total balance from navbar (e.g. 5,936) =====
  function extractTotalPoints() {
    // Primary: the first <p> inside the "View profile" button IS the points number
    const profileBtn = document.querySelector('button[aria-label="View profile"]');
    if (profileBtn) {
      const p = profileBtn.querySelector('p');
      if (p) {
        const raw = p.textContent.trim().replace(/,/g, '');
        const total = parseInt(raw, 10);
        if (!isNaN(total)) {
          console.log('[MsX] Total points extracted (profile btn):', total);
          return { success: true, totalPoints: total };
        }
      }
    }

    // Fallback: the balance <p> is sibling of <img alt="*Member"> inside the same flex row
    const medalImg = document.querySelector('img[alt$="Member"]');
    if (medalImg) {
      const row = medalImg.closest('div');
      const p = row && row.querySelector('p');
      if (p) {
        const raw = p.textContent.trim().replace(/,/g, '');
        const total = parseInt(raw, 10);
        if (!isNaN(total)) {
          console.log('[MsX] Total points extracted (medal img):', total);
          return { success: true, totalPoints: total };
        }
      }
    }

    console.warn('[MsX] Total points element not found');
    return { success: false, error: 'Total points element not found' };
  }

  // ===== Extract account email from profile flyout =====
  async function extractEmail() {
    // 1. Find and click the "View profile" button
    const profileBtn = document.querySelector('button[aria-label="View profile"]');
    if (!profileBtn) {
      return { success: false, error: '"View profile" button not found' };
    }
    profileBtn.click();

    // 2. Poll until the flyout section appears (max 5s)
    let flyout = null;
    for (let i = 0; i < 10; i++) {
      await new Promise(r => setTimeout(r, 500));
      flyout = document.querySelector('[data-trigger="DialogTrigger"] section[role="dialog"]');
      if (flyout) break;
    }
    if (!flyout) {
      return { success: false, error: 'Profile flyout did not appear' };
    }

    // 3. Extract email: <p class="pii truncate"> that is NOT also text-globalBody2Strong (that one is the name)
    let email = null;
    const piiEls = flyout.querySelectorAll('p.pii.truncate');
    for (const p of piiEls) {
      if (!p.className.includes('text-globalBody2Strong')) {
        email = p.textContent.trim();
        break;
      }
    }

    // 4. Close the flyout
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));

    if (!email) return { success: false, error: 'Email element not found in flyout' };
    console.log('[MsX] Email extracted:', email);
    return { success: true, email };
  }

  // ===== Message Listener =====
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.action) {
      case 'getTaskLinks': {
        try {
          const links = getTaskLinksInSection(message.sectionId);
          sendResponse({ links });
        } catch (err) {
          console.error('[MsX] getTaskLinks error:', err);
          sendResponse({ links: [], error: err.message });
        }
        break;
      }

      case 'clickTask': {
        try {
          const result = clickTaskInSection(message.sectionId, message.elementIndex);
          sendResponse(result);
        } catch (err) {
          console.error('[MsX] clickTask error:', err);
          sendResponse({ success: false, error: err.message });
        }
        break;
      }

      case 'clickPointsBreakdown': {
        // Async: polls for dialog to appear → must use promise pattern
        clickPointsBreakdown()
          .then(result => sendResponse(result))
          .catch(err => {
            console.error('[MsX] clickPointsBreakdown error:', err);
            sendResponse({ success: false, error: err.message });
          });
        break; // return true below keeps channel alive
      }

      case 'closeDialog': {
        try {
          const result = closeDialog();
          sendResponse(result);
        } catch (err) {
          console.error('[MsX] closeDialog error:', err);
          sendResponse({ success: false, error: err.message });
        }
        break;
      }

      case 'extractPointsBreakdown': {
        try {
          const result = extractPointsBreakdown();
          sendResponse(result);
        } catch (err) {
          console.error('[MsX] extractPointsBreakdown error:', err);
          sendResponse({ success: false, error: err.message });
        }
        break;
      }

      case 'extractTotalPoints': {
        try {
          const result = extractTotalPoints();
          sendResponse(result);
        } catch (err) {
          console.error('[MsX] extractTotalPoints error:', err);
          sendResponse({ success: false, error: err.message });
        }
        break;
      }

      case 'extractEmail': {
        // Async: uses setTimeout internally → must return true to keep channel open
        extractEmail()
          .then(result => sendResponse(result))
          .catch(err => {
            console.error('[MsX] extractEmail error:', err);
            sendResponse({ success: false, error: err.message });
          });
        break; // return true below keeps channel alive
      }

      default:
        sendResponse({ error: 'Unknown action' });
    }
    return true; // Keep channel open for async
  });

  console.log('[MsX] Content script loaded on', window.location.href);
})();