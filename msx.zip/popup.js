// ===== MsX Popup Controller =====

// Default config
const DEFAULT_CONFIG = {
  delayMin: 3000,
  delayMax: 6000,
  searchLimit: 70,
  closeTabs: true,
  keywordUrl: 'https://raw.githubusercontent.com/tuansave98/MyPublic/refs/heads/main/Msrkw.json'
};

// State
let isRunning = false;

// ===== DOM Elements =====
const $ = (id) => document.getElementById(id);

const elements = {
  // Status
  statusIndicator: $('statusIndicator'),
  statusLabel: $('statusLabel'),

  // Stats
  searchCount: $('searchCount'),
  taskCount: $('taskCount'),

  // Progress
  progressBar: $('progressBar'),
  progressPercent: $('progressPercent'),
  progressDetail: $('progressDetail'),

  // Buttons
  btnStart: $('btnStart'),
  btnStop: $('btnStop'),
  btnOpenRewards: $('btnOpenRewards'),
  btnSearchOnly: $('btnSearchOnly'),
  btnTasksOnly: $('btnTasksOnly'),
  btnSaveConfig: $('btnSaveConfig'),
  btnResetConfig: $('btnResetConfig'),
  btnUpdateKeywords: $('btnUpdateKeywords'),
  btnClearLogs: $('btnClearLogs'),

  // Config inputs
  delayMin: $('delayMin'),
  delayMax: $('delayMax'),
  searchLimit: $('searchLimit'),
  closeTabs: $('closeTabs'),
  keywordUrl: $('keywordUrl'),
  keywordCount: $('keywordCount'),

  // Logs
  logsContainer: $('logsContainer'),

  // Toast
  toast: $('toast'),
  toastIcon: $('toastIcon'),
  toastMessage: $('toastMessage'),

  // Tabs
  tabDashboard: $('tabDashboard'),
  tabConfig: $('tabConfig'),
  tabLogs: $('tabLogs'),
  panelDashboard: $('panelDashboard'),
  panelConfig: $('panelConfig'),
  panelLogs: $('panelLogs')
};

// ===== Tab Switching =====
function initTabs() {
  const tabs = document.querySelectorAll('.tab-btn');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.dataset.tab;

      // Update active tab button
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      // Update active panel
      document.querySelectorAll('.tab-panel').forEach(panel => {
        panel.classList.remove('active');
      });

      const targetPanel = document.getElementById(`panel${capitalize(targetTab)}`);
      if (targetPanel) {
        targetPanel.classList.add('active');
      }
    });
  });
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ===== Config Management =====
async function loadConfig() {
  try {
    const result = await chrome.storage.local.get('msxConfig');
    const config = result.msxConfig || DEFAULT_CONFIG;

    elements.delayMin.value = config.delayMin || DEFAULT_CONFIG.delayMin;
    elements.delayMax.value = config.delayMax || DEFAULT_CONFIG.delayMax;
    elements.searchLimit.value = config.searchLimit || DEFAULT_CONFIG.searchLimit;
    elements.closeTabs.checked = config.closeTabs !== undefined ? config.closeTabs : DEFAULT_CONFIG.closeTabs;
    elements.keywordUrl.value = config.keywordUrl || DEFAULT_CONFIG.keywordUrl;
  } catch (err) {
    console.error('Failed to load config:', err);
  }
}

async function saveConfig() {
  const config = {
    delayMin: parseInt(elements.delayMin.value) || DEFAULT_CONFIG.delayMin,
    delayMax: parseInt(elements.delayMax.value) || DEFAULT_CONFIG.delayMax,
    searchLimit: parseInt(elements.searchLimit.value) || DEFAULT_CONFIG.searchLimit,
    closeTabs: elements.closeTabs.checked,
    keywordUrl: elements.keywordUrl.value.trim() || DEFAULT_CONFIG.keywordUrl
  };

  // Validate
  if (config.delayMin >= config.delayMax) {
    showToast('Delay Min must be less than Delay Max', 'error');
    return;
  }

  try {
    await chrome.storage.local.set({ msxConfig: config });
    showToast('Config saved successfully!', 'success');
  } catch (err) {
    showToast('Failed to save config', 'error');
  }
}

function resetConfig() {
  elements.delayMin.value = DEFAULT_CONFIG.delayMin;
  elements.delayMax.value = DEFAULT_CONFIG.delayMax;
  elements.searchLimit.value = DEFAULT_CONFIG.searchLimit;
  elements.closeTabs.checked = DEFAULT_CONFIG.closeTabs;
  elements.keywordUrl.value = DEFAULT_CONFIG.keywordUrl;
  showToast('Config reset to defaults', 'success');
}

// ===== Keywords =====
async function loadKeywordCount() {
  try {
    const result = await chrome.storage.local.get('msxKeywords');
    const keywords = result.msxKeywords;
    if (keywords && keywords.length) {
      elements.keywordCount.textContent = keywords.length;
    } else {
      // Load from default file
      const response = await fetch(chrome.runtime.getURL('KeywordSearch.json'));
      const data = await response.json();
      elements.keywordCount.textContent = data.keywords ? data.keywords.length : 0;
    }
  } catch (err) {
    elements.keywordCount.textContent = '0';
  }
}

async function updateKeywords() {
  const url = elements.keywordUrl.value.trim() || DEFAULT_CONFIG.keywordUrl;
  if (!url) {
    showToast('Please enter a GitHub Raw URL', 'error');
    return;
  }

  elements.btnUpdateKeywords.disabled = true;
  elements.btnUpdateKeywords.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="spinning">
      <polyline points="23 4 23 10 17 10"/>
      <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
    </svg>
    Updating...
  `;

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const data = await response.json();
    const keywords = data.keywords || data;

    if (!Array.isArray(keywords) || keywords.length === 0) {
      throw new Error('Invalid keyword format');
    }

    await chrome.storage.local.set({ msxKeywords: keywords });
    elements.keywordCount.textContent = keywords.length;
    showToast(`Updated ${keywords.length} keywords!`, 'success');
    addLog(`Keywords updated: ${keywords.length} keywords from remote`, 'success');
  } catch (err) {
    showToast(`Update failed: ${err.message}`, 'error');
    addLog(`Keyword update failed: ${err.message}`, 'error');
  } finally {
    elements.btnUpdateKeywords.disabled = false;
    elements.btnUpdateKeywords.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="23 4 23 10 17 10"/>
        <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
      </svg>
      Update Keywords
    `;
  }
}

// ===== Status & Progress =====
function updateStatus(running) {
  isRunning = running;

  if (running) {
    elements.statusIndicator.classList.add('running');
    elements.statusLabel.textContent = 'Running';
    elements.btnStart.classList.add('hidden');
    elements.btnStop.classList.remove('hidden');
  } else {
    elements.statusIndicator.classList.remove('running');
    elements.statusLabel.textContent = 'Stopped';
    elements.btnStart.classList.remove('hidden');
    elements.btnStop.classList.add('hidden');
  }
}

function updateProgress(data) {
  if (data.searchCount !== undefined) {
    elements.searchCount.textContent = data.searchCount;
  }
  if (data.taskCount !== undefined) {
    elements.taskCount.textContent = data.taskCount;
  }
  if (data.progress !== undefined) {
    const percent = Math.round(data.progress);
    elements.progressBar.style.width = `${percent}%`;
    elements.progressPercent.textContent = `${percent}%`;
  }
  if (data.detail) {
    elements.progressDetail.textContent = data.detail;
  }
}

// ===== Logging =====
function addLog(message, type = 'info') {
  const now = new Date();
  const timeStr = now.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });

  // Clear empty state
  const emptyState = elements.logsContainer.querySelector('.log-empty');
  if (emptyState) emptyState.remove();

  const entry = document.createElement('div');
  entry.className = `log-entry log-${type}`;
  entry.innerHTML = `
    <span class="log-time">${timeStr}</span>
    <span class="log-message">${escapeHtml(message)}</span>
  `;

  elements.logsContainer.insertBefore(entry, elements.logsContainer.firstChild);

  // Keep max 100 entries
  while (elements.logsContainer.children.length > 100) {
    elements.logsContainer.removeChild(elements.logsContainer.lastChild);
  }
}

function clearLogs() {
  elements.logsContainer.innerHTML = `
    <div class="log-empty">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.3">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
      </svg>
      <p>No activity yet</p>
    </div>
  `;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ===== Toast Notification =====
function showToast(message, type = 'success') {
  elements.toast.className = `toast toast-${type}`;
  elements.toastIcon.textContent = type === 'success' ? '✓' : '✕';
  elements.toastMessage.textContent = message;
  elements.toast.classList.remove('hidden');

  setTimeout(() => {
    elements.toast.classList.add('hidden');
  }, 3000);
}



// ===== Communication with Background =====

function sendMessage(action, data = {}) {
  chrome.runtime.sendMessage({ action, ...data }, (response) => {
    if (chrome.runtime.lastError) {
      console.error('Message error:', chrome.runtime.lastError.message);
      return;
    }
    if (response) {
      handleResponse(response);
    }
  });
}

function handleResponse(response) {
  if (response.status !== undefined) {
    updateStatus(response.status === 'running');
  }
  if (response.progress) {
    updateProgress(response.progress);
  }
}

// Listen for messages from background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'progress':
      updateProgress(message.data);
      break;

    case 'log':
      addLog(message.data.message, message.data.level || 'info');
      break;

    case 'status':
      updateStatus(message.data.running);
      break;

    case 'complete':
      updateStatus(false);
      updateProgress(message.data);
      addLog('Farming completed!', 'success');
      showToast('Farming completed! 🎉', 'success');
      break;

    case 'pointsBreakdown': {
      const d = message.data;
      window.lastPointsData = d;
      addLog(
        `📊 ${d.email ?? '?'} | Balance: ${d.totalPoints?.toLocaleString() ?? '?'} | ` +
        `Today: ${d.todayPoints} | ` +
        `Desktop: ${d.activity.desktopSearch.earned}/${d.activity.desktopSearch.max} | ` +
        `Mobile: ${d.activity.mobileSearch.earned}/${d.activity.mobileSearch.max} | ` +
        `Offers: ${d.activity.offers} | ` +
        `Month: ${d.history.thisMonth?.toLocaleString()} | ` +
        `Year: ${d.history.thisYear?.toLocaleString()} | ` +
        `Lifetime: ${d.history.lifetime?.toLocaleString()}`,
        'success'
      );
      // POST is handled by background.js — popup only displays data
      break;
    }

    case 'error':
      addLog(message.data.message, 'error');
      showToast(message.data.message, 'error');
      break;
  }
  sendResponse({ received: true });
  return true;
});

// ===== Start/Stop Controls =====
function startFarming(mode = 'all') {
  const config = {
    delayMin: parseInt(elements.delayMin.value) || DEFAULT_CONFIG.delayMin,
    delayMax: parseInt(elements.delayMax.value) || DEFAULT_CONFIG.delayMax,
    searchLimit: parseInt(elements.searchLimit.value) || DEFAULT_CONFIG.searchLimit,
    closeTabs: elements.closeTabs.checked
  };

  sendMessage('start', { config, mode });
  updateStatus(true);
  addLog(`Farming started (mode: ${mode})`, 'info');
  updateProgress({ progress: 0, detail: 'Initializing...', searchCount: 0, taskCount: 0 });
}

function stopFarming() {
  sendMessage('stop');
  updateStatus(false);
  addLog('Farming stopped by user', 'warning');
  elements.progressDetail.textContent = 'Stopped by user';
}

// ===== Event Listeners =====
function initEventListeners() {
  // Start/Stop
  elements.btnStart.addEventListener('click', () => startFarming('all'));
  elements.btnStop.addEventListener('click', stopFarming);

  // Quick Actions
  elements.btnOpenRewards.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://rewards.bing.com/earn' });
  });
  elements.btnSearchOnly.addEventListener('click', () => startFarming('search'));
  elements.btnTasksOnly.addEventListener('click', () => startFarming('tasks'));

  // Config
  elements.btnSaveConfig.addEventListener('click', saveConfig);
  elements.btnResetConfig.addEventListener('click', resetConfig);
  elements.btnUpdateKeywords.addEventListener('click', updateKeywords);

  // Logs
  elements.btnClearLogs.addEventListener('click', clearLogs);
}

// ===== Get current state from background =====
async function syncState() {
  try {
    sendMessage('getStatus');
  } catch (err) {
    console.error('Failed to sync state:', err);
  }
}

// ===== Initialize =====
document.addEventListener('DOMContentLoaded', async () => {
  initTabs();
  initEventListeners();
  await loadConfig();
  await loadKeywordCount();
  await syncState();

  // Restore last payload from storage so user can review even after popup was closed
  try {
    const stored = await chrome.storage.local.get('msxLastPayload');
    if (stored.msxLastPayload) {
      const { data, sentAt, status, error } = stored.msxLastPayload;
      const statusIcon = status === 'success' ? '✅' : status === 'sending' ? '⏳' : '❌';
      addLog(`🗂️ [Last session ${sentAt}] status=${statusIcon}${status}`, 'info');
      addLog('🗂️ Last payload: ' + JSON.stringify(data), 'info');
      if (error) addLog(`🗂️ Last error: ${error}`, 'error');
    }
  } catch (e) {
    console.warn('[MsX] Could not restore last payload:', e);
  }
});
