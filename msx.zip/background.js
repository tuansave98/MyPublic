// ===== MsX Background Service Worker =====

// State management
let farmingState = {
  running: false,
  mode: 'all', // 'all', 'search', 'tasks'
  searchCount: 0,
  taskCount: 0,
  totalSearches: 70,
  totalTasks: 0,
  currentPhase: 'idle', // 'idle', 'tasks', 'search', 'complete'
  abortController: null
};

// Default config
const DEFAULT_CONFIG = {
  delayMin: 3000,
  delayMax: 6000,
  searchLimit: 70,
  closeTabs: true,
  keywordUrl: 'https://raw.githubusercontent.com/tuansave98/MyPublic/refs/heads/main/Msrkw.json'
};

// ===== Google Sheets API =====
const API_URL = 'https://script.google.com/macros/s/AKfycbzylTcRrB6eBr9_cQpJQRDQWKLfqI5oaHCtC06dv5rD_4j41QJhLSaG1My_e8BDMw4NsA/exec';

async function postToGoogleSheets(data, maxRetries = 3) {
  const sentAt = new Date().toISOString();

  // Persist payload BEFORE sending so we never lose data
  await chrome.storage.local.set({
    msxLastPayload: { data, sentAt, status: 'sending' }
  });
  broadcastLog('📦 Payload: ' + JSON.stringify(data), 'info');
  broadcastLog('📤 Posting data to Google Sheets...', 'info');

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      // Use text/plain to avoid CORS preflight with Google Apps Script
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(data),
        redirect: 'follow'
      });

      // GAS may redirect; read response as text first, then try JSON parse
      const text = await response.text();
      let result;
      try { result = JSON.parse(text); }
      catch { result = { raw: text }; }

      if (response.ok) {
        broadcastLog('✅ Logged to Google Sheets!', 'success');
        await chrome.storage.local.set({
          msxLastPayload: { data, sentAt, status: 'success', apiResult: result }
        });
        return result;
      }
      throw new Error(`HTTP ${response.status} ${response.statusText}`);
    } catch (err) {
      broadcastLog(
        `❌ POST attempt ${attempt}/${maxRetries} failed: [${err.name}] ${err.message}`,
        'error'
      );

      if (attempt < maxRetries) {
        const backoff = 2000 * attempt;
        broadcastLog(`⏳ Retrying in ${backoff / 1000}s...`, 'info');
        await new Promise(r => setTimeout(r, backoff));
      } else {
        // All retries exhausted — persist failure details for later debugging
        broadcastLog(`📋 Stack: ${err.stack ?? '(no stack)'}`, 'error');
        await chrome.storage.local.set({
          msxLastPayload: {
            data, sentAt, status: 'failed',
            error: { name: err.name, message: err.message, stack: err.stack ?? '(no stack)' }
          }
        });
      }
    }
  }
}

// ===== Utility Functions =====
function randomDelay(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function sleep(ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    // Check if farming was stopped
    const checkInterval = setInterval(() => {
      if (!farmingState.running) {
        clearTimeout(timer);
        clearInterval(checkInterval);
        reject(new Error('STOPPED'));
      }
    }, 500);
    // Clean up interval when timer completes
    setTimeout(() => clearInterval(checkInterval), ms + 100);
  });
}

function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

// ===== Message Broadcasting =====
function broadcast(type, data) {
  chrome.runtime.sendMessage({ type, data }).catch(() => {
    // Popup might be closed, ignore
  });
}

function broadcastProgress() {
  const total = farmingState.totalSearches + farmingState.totalTasks;
  const done = farmingState.searchCount + farmingState.taskCount;
  const progress = total > 0 ? (done / total) * 100 : 0;

  broadcast('progress', {
    searchCount: farmingState.searchCount,
    taskCount: farmingState.taskCount,
    progress: progress,
    detail: farmingState.currentPhase === 'search'
      ? `Searching ${farmingState.searchCount}/${farmingState.totalSearches}...`
      : farmingState.currentPhase === 'tasks'
        ? `Completing tasks ${farmingState.taskCount}/${farmingState.totalTasks}...`
        : farmingState.currentPhase === 'complete'
          ? 'Farming complete! 🎉'
          : 'Initializing...'
  });
}

function broadcastLog(message, level = 'info') {
  broadcast('log', { message, level });
}

// ===== Keywords Loading =====
async function loadKeywords() {
  try {
    // Try loading from storage first (user-updated keywords)
    const result = await chrome.storage.local.get('msxKeywords');
    if (result.msxKeywords && result.msxKeywords.length > 0) {
      broadcastLog(`Loaded ${result.msxKeywords.length} keywords from storage`, 'info');
      return result.msxKeywords;
    }
  } catch (err) {
    console.error('Failed to load keywords from storage:', err);
  }

  // Fallback to bundled file
  try {
    const response = await fetch(chrome.runtime.getURL('KeywordSearch.json'));
    const data = await response.json();
    const keywords = data.keywords || data;
    broadcastLog(`Loaded ${keywords.length} keywords from default file`, 'info');
    return keywords;
  } catch (err) {
    console.error('Failed to load default keywords:', err);
    broadcastLog('Failed to load keywords!', 'error');
    return [];
  }
}

// ===== Config Loading =====
async function loadConfig() {
  try {
    const result = await chrome.storage.local.get('msxConfig');
    return { ...DEFAULT_CONFIG, ...(result.msxConfig || {}) };
  } catch (err) {
    return DEFAULT_CONFIG;
  }
}

// ===== Task Farming (Click-based) =====
async function farmTasks(config) {
  farmingState.currentPhase = 'tasks';
  broadcastLog('Starting task farming (click mode)...', 'info');
  broadcastProgress();

  // Helper: wait for content script to be ready and get task links from a section
  async function getTaskLinksFromTab(tabId, sectionId) {
    let taskLinks = [];
    for (let attempt = 0; attempt < 6; attempt++) {
      await sleep(3000);
      try {
        const result = await chrome.tabs.sendMessage(tabId, {
          action: 'getTaskLinks',
          sectionId
        });
        if (result && result.links) {
          taskLinks = result.links;
          if (taskLinks.length > 0) break; // Found tasks, stop polling
        }
      } catch (err) {
        // Content script not injected yet — try injecting manually
        try {
          await chrome.scripting.executeScript({
            target: { tabId },
            files: ['content.js']
          });
        } catch (e) { }
      }
    }
    return taskLinks;
  }

  // Helper: click tasks one by one inside a section, with delay between each
  async function clickTasksInSection(tabId, sectionId, config) {
    const taskLinks = await getTaskLinksFromTab(tabId, sectionId);
    const uncompleted = taskLinks.filter(t => !t.completed);

    broadcastLog(`#${sectionId}: ${uncompleted.length} uncompleted / ${taskLinks.length} total tasks`, 'info');

    for (const task of uncompleted) {
      if (!farmingState.running) break;

      broadcastLog(`Clicking: "${task.title}"`, 'info');

      // Listen for a new tab being created (target="_blank" links)
      let newTabId = null;
      const newTabPromise = new Promise(resolve => {
        function onCreated(tab) {
          newTabId = tab.id;
          chrome.tabs.onCreated.removeListener(onCreated);
          resolve(tab);
        }
        chrome.tabs.onCreated.addListener(onCreated);
        // Timeout fallback if no new tab opens (e.g. same-page navigation)
        setTimeout(() => {
          chrome.tabs.onCreated.removeListener(onCreated);
          resolve(null);
        }, 5000);
      });

      // Send click command to content script
      try {
        const clickResult = await chrome.tabs.sendMessage(tabId, {
          action: 'clickTask',
          sectionId,
          elementIndex: task.elementIndex
        });
        console.log('[MsX BG] Click result:', clickResult);
      } catch (err) {
        broadcastLog(`Failed to click "${task.title}": ${err.message}`, 'error');
        continue;
      }

      // Wait for new tab to open
      const newTab = await newTabPromise;

      if (sectionId === 'quests' && newTab) {
        broadcastLog(`Checking sub-tasks for quest: "${task.title}"`, 'info');
        // Wait for React to render the quest page
        await sleep(3000);
        // Recursively click sub-tasks on the quest page
        await clickTasksInSection(newTab.id, 'quest_page', config);
      } else {
        // Normal task: wait delay for the opened page to register the visit
        const delay = randomDelay(config.delayMin, config.delayMax);
        await sleep(delay);
      }

      // Close the newly opened tab
      if (newTab && config.closeTabs) {
        try {
          await chrome.tabs.remove(newTab.id);
        } catch (e) { }
      }

      farmingState.taskCount++;
      broadcastProgress();
      broadcastLog(`Task completed: "${task.title}" ✓`, 'success');
    }
  }

  // ===== Step 1: Dashboard → #dailyset =====
  broadcastLog('Opening Dashboard page...', 'info');
  const mainTab = await chrome.tabs.create({
    url: 'https://rewards.bing.com/dashboard',
    active: true   // Active so click tracking works properly
  });

  await clickTasksInSection(mainTab.id, 'dailyset', config);

  // ===== Step 2: Navigate to /earn → #moreactivities =====
  if (farmingState.running) {
    broadcastLog('Navigating to Earn page...', 'info');
    await chrome.tabs.update(mainTab.id, { url: 'https://rewards.bing.com/earn' });

    await clickTasksInSection(mainTab.id, 'moreactivities', config);
  }

  // ===== Step 3: Still on /earn → #quests =====
  if (farmingState.running) {
    broadcastLog('Checking Quests section...', 'info');
    await clickTasksInSection(mainTab.id, 'quests', config);
  }

  // Close the main rewards tab
  if (config.closeTabs) {
    try {
      await chrome.tabs.remove(mainTab.id);
    } catch (e) { }
  }

  broadcastLog(`Task farming complete: ${farmingState.taskCount} tasks done`, 'success');
}

// ===== Search Farming =====
async function farmSearches(config) {
  farmingState.currentPhase = 'search';
  broadcastLog('Starting search farming...', 'info');
  broadcastProgress();

  const keywords = await loadKeywords();
  if (keywords.length === 0) {
    broadcastLog('No keywords available!', 'error');
    return;
  }

  // Shuffle and limit keywords
  const shuffled = shuffleArray(keywords);
  const searchKeywords = shuffled.slice(0, config.searchLimit);
  farmingState.totalSearches = searchKeywords.length;

  broadcastLog(`Will perform ${searchKeywords.length} searches`, 'info');
  broadcastProgress();

  for (let i = 0; i < searchKeywords.length; i++) {
    if (!farmingState.running) break;

    const keyword = searchKeywords[i];
    const searchUrl = `https://www.bing.com/search?q=${encodeURIComponent(keyword)}&form=QBLH`;

    broadcastLog(`Search ${i + 1}/${searchKeywords.length}: "${keyword}"`, 'info');

    try {
      const searchTab = await chrome.tabs.create({ url: searchUrl, active: false });

      // Random delay between searches
      const delay = randomDelay(config.delayMin, config.delayMax);
      await sleep(delay);

      // Close tab
      if (config.closeTabs) {
        try {
          await chrome.tabs.remove(searchTab.id);
        } catch (e) {
          // Tab might already be closed
        }
      }

      farmingState.searchCount++;
      broadcastProgress();

    } catch (err) {
      if (err.message === 'STOPPED') throw err;
      broadcastLog(`Search ${i + 1} failed: ${err.message}`, 'error');
    }
  }

  broadcastLog(`Search farming complete: ${farmingState.searchCount} searches done`, 'success');
}

// ===== Collect & Post Data (runs after ALL farming phases) =====
async function collectAndPostData() {
  broadcastLog('📊 Collecting final account data...', 'info');

  // Open a fresh /earn tab for data extraction (must be active so React renders the full navbar)
  const earnTab = await chrome.tabs.create({ url: 'https://rewards.bing.com/earn', active: true });

  // Wait for page to load, then inject content script
  await sleep(4000);
  try {
    await chrome.scripting.executeScript({ target: { tabId: earnTab.id }, files: ['content.js'] });
  } catch (e) { /* already injected by content_scripts declaration */ }
  await sleep(1000);

  let breakdownData = null;
  let totalPoints = null;
  let email = null;

  // ── Step 1: Click "Points breakdown" card ──────────────────────────────
  broadcastLog('Opening Points breakdown...', 'info');
  try {
    const pbResult = await chrome.tabs.sendMessage(earnTab.id, { action: 'clickPointsBreakdown' });
    if (pbResult && pbResult.success) {
      broadcastLog('Points breakdown opened ✓', 'success');

      // Dialog is already confirmed visible by clickPointsBreakdown polling;
      // small extra wait for any render animations to settle
      await sleep(500);

      // Extract breakdown data + navbar totalPoints in parallel
      const [extractResult, totalResult] = await Promise.all([
        chrome.tabs.sendMessage(earnTab.id, { action: 'extractPointsBreakdown' }),
        chrome.tabs.sendMessage(earnTab.id, { action: 'extractTotalPoints' })
      ]);

      if (extractResult && extractResult.success) {
        breakdownData = extractResult.data;
        broadcastLog(`📊 Today: ${breakdownData.todayPoints} pts extracted`, 'success');
      } else {
        broadcastLog(`Failed to extract points data: ${extractResult?.error || 'unknown'}`, 'warning');
      }

      totalPoints = totalResult?.totalPoints ?? null;

      // ── Step 2: Close the dialog (click X button) ───────────────────────
      await sleep(500);
      try {
        const closeResult = await chrome.tabs.sendMessage(earnTab.id, { action: 'closeDialog' });
        if (closeResult && closeResult.success) {
          broadcastLog('Points breakdown dialog closed ✓', 'info');
        }
      } catch (e) {
        broadcastLog('Could not close dialog, continuing...', 'warning');
      }
      await sleep(800); // Let the dialog animation finish

    } else {
      broadcastLog(`Points breakdown not found: ${pbResult?.error || 'unknown'}`, 'warning');
    }
  } catch (err) {
    broadcastLog(`Points breakdown error: ${err.message}`, 'warning');
  }

  // ── Step 3: Extract email from profile flyout ──────────────────────────
  broadcastLog('Extracting account email...', 'info');
  try {
    const emailResult = await chrome.tabs.sendMessage(earnTab.id, { action: 'extractEmail' });
    if (emailResult && emailResult.success) {
      email = emailResult.email;
      broadcastLog(`📧 Email: ${email}`, 'success');
    } else {
      broadcastLog(`Email extraction failed: ${emailResult?.error || 'unknown'}`, 'warning');
    }
  } catch (err) {
    broadcastLog(`Email extraction error: ${err.message}`, 'warning');
  }

  // ── Step 4: Merge, POST to Sheets, & broadcast to popup ────────────────
  if (breakdownData) {
    const payload = {
      email,
      totalPoints,
      ...breakdownData
    };

    broadcastLog(
      `💰 ${email ?? '?'} | Balance: ${payload.totalPoints?.toLocaleString() ?? '?'} | ` +
      `Today: ${payload.todayPoints} | ` +
      `Desktop: ${payload.activity.desktopSearch.earned}/${payload.activity.desktopSearch.max} | ` +
      `Mobile: ${payload.activity.mobileSearch.earned}/${payload.activity.mobileSearch.max}`,
      'success'
    );

    // POST directly from background (persistent) — no longer depends on popup
    await postToGoogleSheets(payload);

    // Broadcast to popup for UI display only (no POST in popup anymore)
    broadcast('pointsBreakdown', payload);
  }

  // Close the earn tab
  try { await chrome.tabs.remove(earnTab.id); } catch (e) { }
}

// ===== Main Farming Controller =====
async function startFarming(config, mode = 'all') {
  if (farmingState.running) {
    broadcastLog('Farming is already running!', 'warning');
    return;
  }

  // Reset state
  farmingState.running = true;
  farmingState.mode = mode;
  farmingState.searchCount = 0;
  farmingState.taskCount = 0;
  farmingState.totalTasks = 0;
  farmingState.totalSearches = config.searchLimit;
  farmingState.currentPhase = 'idle';

  broadcast('status', { running: true });
  broadcastLog(`Farming started (mode: ${mode})`, 'info');

  try {
    // Phase 1: Tasks
    if (mode === 'all' || mode === 'tasks') {
      await farmTasks(config);
    }

    // Phase 2: Search
    if (farmingState.running && (mode === 'all' || mode === 'search')) {
      await farmSearches(config);
    }

    // Phase 3: Collect & Post data (after ALL phases complete)
    if (farmingState.running) {
      await collectAndPostData();
    }

    // Complete
    if (farmingState.running) {
      farmingState.currentPhase = 'complete';
      broadcastProgress();
      broadcast('complete', {
        searchCount: farmingState.searchCount,
        taskCount: farmingState.taskCount,
        progress: 100,
        detail: 'Farming complete! 🎉'
      });
      broadcastLog('All farming activities completed! 🎉', 'success');
    }
  } catch (err) {
    if (err.message === 'STOPPED') {
      broadcastLog('Farming stopped by user', 'warning');
    } else {
      broadcastLog(`Farming error: ${err.message}`, 'error');
      broadcast('error', { message: err.message });
    }
  } finally {
    farmingState.running = false;
    farmingState.currentPhase = 'idle';
    broadcast('status', { running: false });
  }
}

function stopFarming() {
  farmingState.running = false;
  farmingState.currentPhase = 'idle';
  broadcast('status', { running: false });
  broadcastLog('Farming stopped', 'warning');
}

// ===== Helper =====
function truncateUrl(url) {
  if (url.length > 60) {
    return url.substring(0, 57) + '...';
  }
  return url;
}

// ===== Message Listener =====
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case 'start': {
      const config = { ...DEFAULT_CONFIG, ...(message.config || {}) };
      const mode = message.mode || 'all';
      startFarming(config, mode);
      sendResponse({
        status: 'running',
        progress: {
          searchCount: 0,
          taskCount: 0,
          progress: 0,
          detail: 'Starting...'
        }
      });
      break;
    }

    case 'stop':
      stopFarming();
      sendResponse({ status: 'stopped' });
      break;

    case 'getStatus':
      sendResponse({
        status: farmingState.running ? 'running' : 'stopped',
        progress: {
          searchCount: farmingState.searchCount,
          taskCount: farmingState.taskCount,
          progress: farmingState.totalSearches + farmingState.totalTasks > 0
            ? ((farmingState.searchCount + farmingState.taskCount) / (farmingState.totalSearches + farmingState.totalTasks)) * 100
            : 0,
          detail: farmingState.running ? 'Farming in progress...' : 'Ready to start'
        }
      });
      break;

    case 'taskUrls':
      // Received from content script
      if (message.urls) {
        broadcastLog(`Received ${message.urls.length} task URLs from rewards page`, 'info');
      }
      sendResponse({ received: true });
      break;

    default:
      sendResponse({ error: 'Unknown action' });
  }

  return true; // Keep message channel open for async responses
});

// ===== Extension Install Handler =====
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    // Set default config
    await chrome.storage.local.set({ msxConfig: DEFAULT_CONFIG });

    // Load default keywords into storage
    try {
      const response = await fetch(chrome.runtime.getURL('KeywordSearch.json'));
      const data = await response.json();
      if (data.keywords) {
        await chrome.storage.local.set({ msxKeywords: data.keywords });
      }
    } catch (err) {
      console.error('Failed to load default keywords:', err);
    }

    console.log('MsX Extension installed successfully!');
  }
});
